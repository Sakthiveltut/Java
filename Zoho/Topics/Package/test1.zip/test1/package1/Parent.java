package package1;
public class Parent{
		
	public void parent(){
	
		System.out.println("Parent");
	
	}
}
	