//package package1;
import package1.Parent;
import package2.Child;


public class Main{
		
	public static void main(String[] args){
	
		System.out.println("Main");

		Parent p = new Parent();
		p.parent();

		Child c = new Child();
		c.child();
	
	}
}
	