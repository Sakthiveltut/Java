package package2;
public class Child{
		
	public void child(){
	
		System.out.println("Child");
	
	}
}
	